
import json
import base64
import zlib

ARCHIVED = {"_archived_action_v1": True}

def replay_action(raw):
    result = json.loads(raw)
    if isinstance(result, dict) and result.get("_archived_action_v1") is True:
        raise ValueError(
            "?????????????????????????????"
        )
    if isinstance(result, dict) and set(result) == {"_tap_batch_zlib_v1"}:
        compressed = base64.b64decode(result["_tap_batch_zlib_v1"])
        result = json.loads(zlib.decompress(compressed).decode("utf-8"))
    return result

def store_action(db, player, key, payload, kind, result, *, postgres):
    if postgres and isinstance(result, dict) and "spent" in result:
        db.execute(
            """INSERT INTO action_spend_totals
               (player,kind,action_count,total_spent)
               VALUES(?,?,1,?)
               ON CONFLICT(player,kind) DO UPDATE SET
               action_count=action_spend_totals.action_count+1,
               total_spent=badd(
                   action_spend_totals.total_spent,
                   excluded.total_spent
               )""",
            (player, kind, result["spent"])
        )

    if postgres and kind in ("sunpress", "upgrade", "tap_batch"):
        stored = json.dumps(ARCHIVED, separators=(",", ":"))
    else:
        stored = json.dumps(result)

    db.execute(
        "INSERT INTO actions VALUES(?,?,?,?)",
        (player, key, payload, stored)
    )
