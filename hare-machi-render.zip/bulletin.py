"""Persistent player announcements and player-to-admin messages.

All text is rendered with textContent on the client. Every player query is scoped
by the authenticated player ID, never by a client-supplied ID.
"""
import secrets


def initialize(db):
    with db:
        db.execute('''CREATE TABLE IF NOT EXISTS bulletin_posts (
            id TEXT PRIMARY KEY, body TEXT NOT NULL, target_player TEXT,
            created_at BIGINT NOT NULL, deleted_at BIGINT)''')
        db.execute('''CREATE TABLE IF NOT EXISTS bulletin_reads (
            post_id TEXT NOT NULL, player_id TEXT NOT NULL,
            read_at BIGINT NOT NULL, PRIMARY KEY(post_id,player_id))''')
        db.execute('''CREATE TABLE IF NOT EXISTS bulletin_messages (
            id TEXT PRIMARY KEY, player_id TEXT NOT NULL,
            body TEXT NOT NULL, created_at BIGINT NOT NULL)''')
        # Import existing globally broadcast announcements exactly once.
        # Old announcements only contained revisions (not timestamps).
        db.execute('''INSERT INTO bulletin_posts(id,body,target_player,created_at,deleted_at)
            SELECT 'legacy-' || revision,body,NULL,0,NULL
            FROM site_announcements WHERE body<>'' ON CONFLICT DO NOTHING''')


def player_posts(db, player_id):
    return [dict(row) for row in db.execute('''
        SELECT p.id,p.body,p.created_at,CASE WHEN p.target_player IS NULL
             THEN 0 ELSE 1 END AS personal,r.read_at
        FROM bulletin_posts p LEFT JOIN bulletin_reads r
          ON r.post_id=p.id AND r.player_id=?
        WHERE p.deleted_at IS NULL AND (p.target_player IS NULL OR p.target_player=?)
        ORDER BY p.created_at DESC,p.id DESC LIMIT 250''',(player_id,player_id))]


def mark_read(db,player_id,post_id,now):
    if not isinstance(post_id,str) or len(post_id)>90:
        raise ValueError('お知らせIDが不正です。')
    if not db.execute('''SELECT 1 FROM bulletin_posts WHERE id=? AND deleted_at IS NULL
        AND (target_player IS NULL OR target_player=?)''',(post_id,player_id)).fetchone():
        raise ValueError('対象のお知らせがありません。')
    with db:
        db.execute('''INSERT INTO bulletin_reads(post_id,player_id,read_at)
            VALUES(?,?,?) ON CONFLICT DO NOTHING''',(post_id,player_id,now))
    return {'ok':True}


def send_message(db,player_id,body,now):
    if not isinstance(body,str) or not 1<=len(body.strip())<=1000:
        raise ValueError('メッセージは1～1000文字で入力してください。')
    with db:
        db.execute('INSERT INTO bulletin_messages VALUES(?,?,?,?)',
                   (secrets.token_hex(16),player_id,body.strip(),now))
    return {'ok':True}


def admin_posts(db):
    return [dict(row) for row in db.execute('''
        SELECT p.id,p.body,p.created_at,p.deleted_at,
               t.student_id,t.display_name,
               (SELECT COUNT(*) FROM bulletin_reads r WHERE r.post_id=p.id) AS read_count
        FROM bulletin_posts p LEFT JOIN players t ON t.id=p.target_player
        WHERE p.deleted_at IS NULL ORDER BY p.created_at DESC,p.id DESC LIMIT 250''')]


def admin_messages(db):
    return [dict(row) for row in db.execute('''
        SELECT m.id,m.body,m.created_at,p.student_id,p.display_name,p.class_number
        FROM bulletin_messages m JOIN players p ON p.id=m.player_id
        ORDER BY m.created_at DESC,m.id DESC LIMIT 300''')]


def publish(db,body,student_id,now):
    if not isinstance(body,str) or not 1<=len(body.strip())<=500:
        raise ValueError('お知らせは1～500文字で入力してください。')
    if student_id not in (None,''):
        if not isinstance(student_id,str) or not (len(student_id)==4 and student_id.isascii() and student_id.isdecimal()):
            raise ValueError('学籍番号が不正です。')
        target=db.execute('SELECT id FROM players WHERE student_id=?',(student_id,)).fetchone()
        if not target:raise ValueError('指定されたプレイヤーは登録されていません。')
        player_id=target[0]
    else:player_id=None
    post_id=secrets.token_hex(16)
    with db:
        db.execute('INSERT INTO bulletin_posts VALUES(?,?,?,?,NULL)',
                   (post_id,body.strip(),player_id,now))
    return {'ok':True,'id':post_id}


def delete(db,post_id,now):
    if not isinstance(post_id,str) or len(post_id)>90:
        raise ValueError('お知らせIDが不正です。')
    with db:
        result=db.execute('UPDATE bulletin_posts SET deleted_at=? WHERE id=? AND deleted_at IS NULL',
                          (now,post_id))
    if result.rowcount==0:raise ValueError('お知らせが見つかりません。')
    return {'ok':True}
