(() => {
  const big = n => BigInt(n ?? 0);
  const scientificThreshold = 10n ** 31n; // 1000穣
  const isLarge = n => n >= scientificThreshold || n <= -scientificThreshold;
  const names = ['', '万', '億', '兆', '京', '垓', '秭', '穣'];

  function fmt(n) {
    if (typeof n === 'number' && !Number.isFinite(n)) return '—';
    if (typeof n === 'number' && !Number.isInteger(n)) return n.toLocaleString('ja-JP');
    const value = big(n);
    const sign = value < 0n ? '−' : '';
    const magnitude = value < 0n ? -value : value;
    if (magnitude < 10n ** 16n) return sign + magnitude.toLocaleString('ja-JP');
    const digits = magnitude.toString();
    if (isLarge(magnitude)) {
      let exponent = digits.length - 1;
      let leading = Number(digits.slice(0, 5)) + (digits[5] >= '5' ? 1 : 0);
      if (leading === 100000) {
        leading = 10000;
        exponent++;
      }
      const mantissa = String(leading);
      return sign + mantissa[0] + '.' + mantissa.slice(1) + 'e+' + exponent;
    }
    const groups = [];
    for (let end = digits.length; end > 0; end -= 4) {
      groups.unshift(digits.slice(Math.max(0, end - 4), end));
    }
    return sign + groups.map((group, i) => group + names[groups.length - i - 1]).join('');
  }

  function parseWhole(input, scale = 0) {
    const match = /^([0-9]+)(?:\.([0-9]+))?(?:[eE]([+-]?[0-9]{1,4}))?$/.exec(input.trim());
    if (!match || input.length > 1010) return null;
    const [, whole, fraction = '', exponent = '0'] = match;
    const digits = (whole + fraction).replace(/^0+/, '');
    if (!digits) return 0n;
    const shift = Number(exponent) - fraction.length + scale;
    if (shift >= 0) return digits.length + shift <= 1000 ? BigInt(digits + '0'.repeat(shift)) : null;
    if (-shift >= digits.length || /[1-9]/.test(digits.slice(shift))) return null;
    return BigInt(digits.slice(0,shift));
  }

  window.TeruNumber = {big, fmt, isLarge, parseWhole};
})();
