(() => {
  const big = n => BigInt(n ?? 0);
  const scientificThreshold = 10n ** 31n; // 1000穣
  const names = ['', '万', '億', '兆', '京', '垓', '秭', '穣'];

  function fmt(n) {
    if (typeof n === 'number' && !Number.isInteger(n)) return n.toLocaleString('ja-JP');
    const value = big(n);
    const sign = value < 0n ? '−' : '';
    const magnitude = value < 0n ? -value : value;
    if (magnitude < 10n ** 16n) return sign + magnitude.toLocaleString('ja-JP');
    const digits = magnitude.toString();
    if (magnitude >= scientificThreshold) {
      let exponent = digits.length - 1;
      let leading = Number(digits.slice(0, 5)) + (digits[5] >= '5' ? 1 : 0);
      if (leading === 100000) {
        leading = 10000;
        exponent++;
      }
      const mantissa = String(leading);
      return sign + mantissa[0] + '.' + mantissa.slice(1) + 'e+' + exponent;
    }
    const groups = [];
    for (let end = digits.length; end > 0; end -= 4) {
      groups.unshift(digits.slice(Math.max(0, end - 4), end));
    }
    return sign + groups.map((group, i) => group + names[groups.length - i - 1]).join('');
  }

  window.TeruNumber = {big, fmt};
})();
