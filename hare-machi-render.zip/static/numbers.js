(() => {
  const big = n => BigInt(n ?? 0);
  const scientificThreshold = 10n ** 31n; // 1000穣
  const isLarge = n => n >= scientificThreshold || n <= -scientificThreshold;
  const names = ['', '万', '億', '兆', '京', '垓', '秭', '穣'];

  function fmt(n) {
    if (typeof n === 'number' && !Number.isFinite(n)) return '—';
    if (typeof n === 'number' && !Number.isInteger(n)) return n.toLocaleString('ja-JP');
    const value = big(n);
    const sign = value < 0n ? '−' : '';
    const magnitude = value < 0n ? -value : value;
    if (magnitude < 10n ** 16n) return sign + magnitude.toLocaleString('ja-JP');
    const digits = magnitude.toString();
    if (isLarge(magnitude)) {
      let exponent = digits.length - 1;
      let leading = Number(digits.slice(0, 5)) + (digits[5] >= '5' ? 1 : 0);
      if (leading === 100000) {
        leading = 10000;
        exponent++;
      }
      const mantissa = String(leading);
      return sign + mantissa[0] + '.' + mantissa.slice(1) + 'e+' + exponent;
    }
    const groups = [];
    for (let end = digits.length; end > 0; end -= 4) {
      groups.unshift(digits.slice(Math.max(0, end - 4), end));
    }
    return sign + groups.map((group, i) => group + names[groups.length - i - 1]).join('');
  }

  // PostgreSQL NUMERIC supports at most 131072 digits before the decimal.
  // Leave headroom for monetary multiplication and running totals.
  const MAX_INTEGER_DIGITS = 131072;
  function parseWhole(input, scale = 0) {
    const source = String(input ?? '').trim();
    if (source.length > 4096) return null;
    const match = /^([0-9]+)(?:\.([0-9]+))?(?:[eE]([+-]?[0-9]+))?$/.exec(source);
    if (!match) return null;
    const [, whole, fraction = '', exponent = '0'] = match;
    const digits = (whole + fraction).replace(/^0+/, '');
    if (!digits) return 0n;
    if (exponent.replace(/^[+-]?0*/, '').length > 6) return null;
    const shift = Number(exponent) - fraction.length + scale;
    if (!Number.isSafeInteger(shift)) return null;
    if (shift >= 0) {
      if (digits.length + shift > MAX_INTEGER_DIGITS) return null;
      return BigInt(digits + '0'.repeat(shift));
    }
    const cut = digits.length + shift;
    if (cut <= 0 || /[1-9]/.test(digits.slice(cut))) return null;
    return BigInt(digits.slice(0, cut));
  }

  window.TeruNumber = {big, fmt, isLarge, parseWhole};
})();
