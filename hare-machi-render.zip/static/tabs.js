/* Replace selects with accessible, keyboard-operable tab widgets. */
(()=>{for(const select of document.querySelectorAll('select')){
 const group=document.createElement('div');for(const a of select.attributes)group.setAttribute(a.name,a.value);
 group.classList.add('choice-tabs');group.setAttribute('role','tablist');group.setAttribute('aria-label',[...select.parentElement.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim()||'選択');
 const options=[...select.options].map(o=>({value:o.value,textContent:o.textContent}));let value=select.value;
 function sync(){for(const b of group.children){const active=b.dataset.value===value;b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;}}
 Object.defineProperty(group,'value',{get:()=>value,set:v=>{value=String(v);sync();}});Object.defineProperty(group,'selectedOptions',{get:()=>options.filter(o=>o.value===value)});
 for(const o of options){const button=document.createElement('button');button.type='button';button.setAttribute('role','tab');button.setAttribute('aria-label',o.textContent);button.dataset.value=o.value;button.textContent=o.textContent;button.onclick=()=>{group.value=o.value;group.dispatchEvent(new Event('change',{bubbles:true}));};group.append(button);}
 group.onkeydown=e=>{const index=options.findIndex(o=>o.value===value);let next=index;if(e.key==='ArrowRight')next=(index+1)%options.length;else if(e.key==='ArrowLeft')next=(index+options.length-1)%options.length;else if(e.key==='Home')next=0;else if(e.key==='End')next=options.length-1;else return;e.preventDefault();group.children[next].click();group.children[next].focus();};
 select.replaceWith(group);if(group.parentElement.tagName==='LABEL'){const label=group.parentElement,field=document.createElement('div');field.className='choice-field';field.append(...label.childNodes);label.replaceWith(field);}sync();
}})();

/* RULEBOOK_TABS_START */
(()=> {
  function init() {
    const section = document.getElementById('tp-page-rules');
    const original = document.getElementById('rulebook-default');
    if (!section || !original || original.dataset.tabsReady) return;
    original.dataset.tabsReady = 'true';
    const definitions = [
      ['start','はじめに','ゲームの概要・開催期間'],
      ['ranking','勝ち方','目標・攻略・順位'],
      ['factory','工場・図鑑','製造・強化・レア坊主'],
      ['market','市場・銀行','出荷・購入・資金運用'],
      ['tax','税金','売上税・総資産税']
    ];
    const groups = new Map();
    const bar = document.createElement('div');
    bar.className = 'rb-tabs';
    bar.setAttribute('role','tablist');
    bar.setAttribute('aria-label','ルールブックのジャンル');
    const content = document.createElement('div');
    content.className = 'rb-content';
    for (const [key,label,description] of definitions) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'rb-tab';
      button.id = 'rb-tab-' + key;
      button.setAttribute('role','tab');
      button.setAttribute('aria-controls','rb-panel-' + key);
      button.setAttribute('aria-selected',key === 'start' ? 'true':'false');
      button.tabIndex = key === 'start' ? 0:-1;
      button.textContent = label;
      bar.append(button);
      const panel = document.createElement('div');
      panel.className = 'rb-panel';
      panel.id = 'rb-panel-' + key;
      panel.setAttribute('role','tabpanel');
      panel.setAttribute('aria-labelledby',button.id);
      panel.hidden = key !== 'start';
      const heading = document.createElement('p');
      heading.className = 'rb-description';
      heading.textContent = description;
      panel.append(heading);
      content.append(panel);
      groups.set(key,panel);
      button.addEventListener('click',()=>activate(key));
    }
    function activate(key) {
      for (const [name,panel] of groups) {
        const active = name === key;
        panel.hidden = !active;
        const tab = document.getElementById('rb-tab-' + name);
        tab.setAttribute('aria-selected',String(active));
        tab.tabIndex = active ? 0:-1;
      }
    }
    const tabs = [...bar.querySelectorAll('.rb-tab')];
    bar.addEventListener('keydown',event=>{
      const i = tabs.indexOf(document.activeElement);
      if (i < 0 || !['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
      event.preventDefault();
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length-1 : (i+(event.key === 'ArrowRight'?1:-1)+tabs.length)%tabs.length;
      tabs[next].click();
      tabs[next].focus();
      tabs[next].scrollIntoView({block:'nearest',inline:'nearest'});
    });
    const intro = [...section.children].filter(el=>el.tagName==='DETAILS');
    const entries = [...intro,...original.querySelectorAll(':scope > details')];
    function category(title) {
      if (/税|課税/.test(title)) return 'tax';
      if (/市場|銀行|購入|出荷|販売/.test(title)) return 'market';
      if (/製造|つくる|強化|レア|図鑑|工場/.test(title)) return 'factory';
      if (/勝|順位|データ|ランキング|コツ/.test(title)) return 'ranking';
      return 'start';
    }
    for (const details of entries) {
      const title = details.querySelector('summary')?.textContent || '';
      details.removeAttribute('name');
      groups.get(category(title)).append(details);
    }
    original.prepend(bar,content);
    original.classList.add('rb-organized');
    for (const [,panel] of groups) {
      if (panel.querySelector('details') === null) panel.hidden = true;
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();
(() => {
  function init() {
    const page=document.getElementById('tp-page-rules');
    const standard=document.getElementById('rulebook-default');
    const custom=document.getElementById('rulebook-custom');
    const tabs=standard?.querySelector('.rb-tabs');
    const contents=standard?.querySelector('.rb-content');
    if(!page||!standard||!custom||!tabs||!contents||page.dataset.customTabsReady) return;
    page.dataset.customTabsReady='1';
    // The existing navigation lived inside a node hidden by app.js
    // whenever the administrator supplied custom rules.
    page.insertBefore(tabs,standard);
    page.insertBefore(contents,standard);
    const buttons=[...tabs.querySelectorAll('[role="tab"]')];
    const panels=[...contents.querySelectorAll('[role="tabpanel"]')];
    const map=Object.fromEntries(panels.map(p=>[p.id.replace('rb-panel-',''),p]));
    const extra=document.createElement('button');
    extra.type='button'; extra.className='rb-tab'; extra.id='rb-tab-full';
    extra.setAttribute('role','tab');extra.setAttribute('aria-controls','rb-panel-full');
    extra.textContent='全文';
    const full=document.createElement('section');
    full.id='rb-panel-full';full.className='rb-panel';
    full.setAttribute('role','tabpanel');full.setAttribute('aria-labelledby',extra.id);
    contents.append(full); tabs.append(extra);
    buttons.push(extra);panels.push(full);
    let selected='start';
    function activate(key) {
      selected=key;
      for(const b of buttons) {
        const active=b.id==='rb-tab-'+key;
        b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;
      }
      for(const p of panels) p.hidden=p.id!=='rb-panel-'+key;
    }
    for(const b of buttons) b.addEventListener('click',()=>activate(b.id.slice(7)));
    tabs.addEventListener('keydown',event=>{
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
      const visible=buttons.filter(b=>!b.hidden);
      const i=visible.indexOf(document.activeElement);if(i<0)return;
      event.preventDefault();
      const j=event.key==='Home'?0:event.key==='End'?visible.length-1:
        (i+(event.key==='ArrowRight'?1:-1)+visible.length)%visible.length;
      visible[j].click();visible[j].focus();
    });
    const words=[
      ['tax',/税|課税|徴収|税率|税額/],
      ['market',/市場|売買|出荷|購入|販売|価格|売り手|銀行|借入|借金|預け|払入|返済|満期/],
      ['factory',/製造|工場|強化|タップ|作業|レア|図鑑|生産|自動/],
      ['ranking',/勝|順位|ランキング|部門|純利益|集計|クラス/]
    ];
    function classify(s) {
      const scores=words.map(([key,pattern])=>[key,(s.match(new RegExp(pattern.source,'g'))||[]).length]);
      scores.sort((a,b)=>b[1]-a[1]);return scores[0][1]>0?scores[0][0]:'start';
    }
    let last='';
    function refresh() {
      const raw=custom.textContent||'';
      if(raw===last)return;
      last=raw;
      const isCustom=!!raw.trim();
      page.classList.toggle('rb-custom-active',isCustom);
      extra.hidden=!isCustom;
      for(const p of panels)p.querySelectorAll('.rb-custom-text').forEach(node=>node.remove());
      if(isCustom) {
        const pieces=raw.match(/[^。！？!?\n]+[。！？!?]?|\n+/gu)||[raw];
        const grouped={start:[],ranking:[],factory:[],market:[],tax:[]};
        for(const piece of pieces)if(piece.trim())grouped[classify(piece)].push(piece.trim());
        function block(text) {
          const el=document.createElement('article');el.className='rb-custom-text';
          el.textContent=text;return el;
        }
        for(const [key,parts] of Object.entries(grouped)) {
          let buffer='';
          for(const text of parts) {
            if(buffer.length>250){map[key].append(block(buffer));buffer='';}
            buffer+=text;
          }
          if(buffer)map[key].append(block(buffer));
        }
        full.append(block(raw));
      }
      activate(selected==='full'&&!isCustom?'start':selected);
    }
    // Custom rules arrive asynchronously after the initial page load.
    new MutationObserver(refresh).observe(custom,{childList:true,characterData:true,subtree:true});
    page.classList.add('rb-custom-tabs-ready');
    last=null;refresh();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();
/* RULEBOOK_TABS_END */
