/* Replace selects with accessible, keyboard-operable tab widgets. */
(()=>{for(const select of document.querySelectorAll('select')){
 const group=document.createElement('div');for(const a of select.attributes)group.setAttribute(a.name,a.value);
 group.classList.add('choice-tabs');group.setAttribute('role','tablist');group.setAttribute('aria-label',[...select.parentElement.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim()||'選択');
 const options=[...select.options].map(o=>({value:o.value,textContent:o.textContent}));let value=select.value;
 function sync(){for(const b of group.children){const active=b.dataset.value===value;b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;}}
 Object.defineProperty(group,'value',{get:()=>value,set:v=>{value=String(v);sync();}});Object.defineProperty(group,'selectedOptions',{get:()=>options.filter(o=>o.value===value)});
 for(const o of options){const button=document.createElement('button');button.type='button';button.setAttribute('role','tab');button.setAttribute('aria-label',o.textContent);button.dataset.value=o.value;button.textContent=o.textContent;button.onclick=()=>{group.value=o.value;group.dispatchEvent(new Event('change',{bubbles:true}));};group.append(button);}
 group.onkeydown=e=>{const index=options.findIndex(o=>o.value===value);let next=index;if(e.key==='ArrowRight')next=(index+1)%options.length;else if(e.key==='ArrowLeft')next=(index+options.length-1)%options.length;else if(e.key==='Home')next=0;else if(e.key==='End')next=options.length-1;else return;e.preventDefault();group.children[next].click();group.children[next].focus();};
 select.replaceWith(group);if(group.parentElement.tagName==='LABEL'){const label=group.parentElement,field=document.createElement('div');field.className='choice-field';field.append(...label.childNodes);label.replaceWith(field);}sync();
}})();
