/* Installed exact V2 browser formatter */
/* Exact sparse V2 numbers for browser tables, rankings, and chart axes.
   Does NOT change writes or convert astronomical amounts to Number. */
(function(root){
'use strict';
const MAX_TERMS=2048, MAX_COEFF_DIGITS=10000, MAX_EXPONENT_DIGITS=256;
function abs(x){return x<0n?-x:x;}
function digits(x){return abs(x).toString().length;}
function parse(wire){
 if(typeof wire!=='string'||!wire.startsWith('S1:'))throw Error('V2数値形式が不正です');
 const raw=wire.slice(3);if(!raw)return [];
 const parts=raw.split(',');if(parts.length>MAX_TERMS)throw Error('V2数値の項数が多すぎます');
 const terms=new Map();
 for(const part of parts){
  const m=/^(-?\d+)@(\d+)$/.exec(part);if(!m||m[1].replace('-','').length>MAX_COEFF_DIGITS||m[2].length>MAX_EXPONENT_DIGITS)throw Error('V2数値の形式が不正です');
  const exp=BigInt(m[2]),coeff=BigInt(m[1]);if(coeff===0n)throw Error('ゼロ係数は禁止です');
  const key=exp.toString();terms.set(key,(terms.get(key)||0n)+coeff);
 }
 const result=[...terms].filter(p=>p[1]!==0n).map(([e,c])=>[BigInt(e),c]);
 result.sort((a,b)=>a[0]<b[0]?-1:a[0]>b[0]?1:0);
 if(result.length>MAX_TERMS)throw Error('V2数値の項数が多すぎます');
 return result;
}
function combine(a,b,subtract=false){
 const merged=new Map();
 for(const [e,c] of a)merged.set(e.toString(),(merged.get(e.toString())||0n)+c);
 for(const [e,c] of b)merged.set(e.toString(),(merged.get(e.toString())||0n)+(subtract?-c:c));
 return [...merged].filter(x=>x[1]!==0n).map(([e,c])=>[BigInt(e),c]).sort((x,y)=>x[0]<y[0]?-1:x[0]>y[0]?1:0);
}
function sign(terms){
 if(!terms.length)return 0;
 let exponent=terms[0][0],carry=terms[0][1],nonzero=false;
 for(let i=1;i<terms.length;i++){
  const next=terms[i];const gap=next[0]-exponent;let quotient,remainderExists;
  if(gap>BigInt(digits(carry))){
   quotient=carry<0n?-1n:0n;remainderExists=carry!==0n;
  }else{
   const base=10n**gap;
   // floor division for negative coefficients (JS division truncates toward zero).
   quotient=carry/base;let remainder=carry%base;
   if(remainder<0n){quotient-=1n;remainder+=base;}
   remainderExists=remainder!==0n;
  }
  nonzero=nonzero||remainderExists;carry=quotient+next[1];exponent=next[0];
 }
 return carry>0n?1:carry<0n?-1:nonzero?1:0;
}
function compare(a,b){return sign(combine(parse(a),parse(b),true));}
function magnitude(terms){
 if(!terms.length||sign(terms)===0)return null;
 const positive=sign(terms)<0?terms.map(([e,c])=>[e,-c]):terms;
 let high=0n;
 for(const [e,c] of positive){const limit=e+BigInt(digits(c));if(limit>high)high=limit;}
 const ge=(e)=>sign(combine(positive,[[e,1n]],true))>=0;
 let lo=0n,hi=high;
 while(lo<hi){const middle=(lo+hi+1n)/2n;if(ge(middle))lo=middle;else hi=middle-1n;}
 return lo;
}
function compact(wire,precision=5){
 const terms=parse(wire),polarity=sign(terms);
 if(polarity===0)return '0';
 const absolute=polarity<0?terms.map(([e,c])=>[e,-c]):terms;
 const power=magnitude(terms);
 const prefix=polarity<0?'−':'';
 if(power<=14n){
  let whole=0n;
  for(let place=power;place>=0n;place--){
   let lo=0n,hi=9n;
   while(lo<hi){
    const mid=(lo+hi+1n)/2n;
    const candidate=whole*10n+mid;
    if(sign(combine(absolute,[[place,candidate]],true))>=0)lo=mid;else hi=mid-1n;
   }
   whole=whole*10n+lo;
  }
  return prefix+whole.toLocaleString('ja-JP');
 }
 const count=Math.max(1,Math.min(8,Math.trunc(precision)));
 let coeff=0n;
 for(let index=0;index<count;index++){
  const place=power-BigInt(index);
  if(place<0n)break;
  let lo=0n,hi=9n;
  while(lo<hi){
   const mid=(lo+hi+1n)/2n;
   const proposed=coeff*10n+mid;
   if(sign(combine(absolute,[[place,proposed]],true))>=0)lo=mid;
   else hi=mid-1n;
  }
  coeff=coeff*10n+lo;
 }
 const raw=coeff.toString().padStart(count,'0');
 return prefix+raw[0]+(raw.length>1?'.'+raw.slice(1):'')+'e+'+power.toString();
}
function chartMagnitude(wire,max=300){
 const p=magnitude(parse(wire));if(p===null)return 0;
 // Explicitly log-scaled. A bounded double is for rendering only, never settlement.
 const ceiling=BigInt(Math.max(1,Math.trunc(max)));
 return Number(p>ceiling?ceiling:p);
}
root.TeruV2Number={parse,sign:(wire)=>sign(parse(wire)),compare,compact,chartMagnitude,magnitude:(wire)=>{const m=magnitude(parse(wire));return m===null?null:m.toString();}};
})(typeof window==='object'?window:globalThis);

'use strict';
const $=id=>document.getElementById(id);
let state=null;
const fields=[
 ['gross','合計購入額'],
 ['illustrative_fee','参考手数料'],
 ['illustrative_debit','参考引落額'],
 ['current_cash','現在の所持金'],
 ['cash_after_preview','試算後の所持金'],
 ['current_stock','現在の在庫'],
 ['stock_after_preview','試算後の在庫']
];
function setError(message){$('error').textContent=message||'';$('error').hidden=!message;}
async function request(path,body){
 const opts={credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}};
 if(body!==undefined){opts.method='POST';opts.headers['Content-Type']='application/json';opts.body=JSON.stringify(body);}
 const response=await fetch(path,opts);
 let data;
 try{data=await response.json();}catch(_){throw Error('サーバーの応答を読み取れませんでした。');}
 if(response.status===401){$('status').textContent='ログインが必要です。';throw Error('ゲームに戻ってログインしてください。');}
 if(!response.ok)throw Error(data.error||'API通信に失敗しました (HTTP '+response.status+')');
 return data;
}
async function refresh(){
 $('refresh').disabled=true;$('status').textContent='資産を確認中です。';setError('');
 try{
  const next=await request('/api/v2/balances');
  if(next.mode!=='read-only'||next.format!=='S1'||!Array.isArray(next.stock))throw Error('V2資産情報の形式が異なります。');
  state=next;$('cash').textContent=window.TeruV2Number.compact(next.cash)+' ('+next.cash+')';$('balance').hidden=false;
  const chart=$('v2-stock-chart');chart.replaceChildren();
  for(const item of next.stock){
   const entry=document.createElement('div');entry.className='v2-stock-entry';
   const desc=document.createElement('span');desc.textContent=item.product+': '+window.TeruV2Number.compact(item.quantity);
   const bar=document.createElement('div');bar.className='v2-stock-bar';
   const fill=document.createElement('div');fill.className='v2-stock-fill';
   fill.style.width=(window.TeruV2Number.chartMagnitude(item.quantity,300)/3)+'%';
   bar.appendChild(fill);entry.append(desc,bar);chart.appendChild(entry);
  }
  const select=$('product');const selected=select.value;select.replaceChildren();
  for(const item of next.stock){if(!item.product)continue;const opt=document.createElement('option');opt.value=item.product;opt.textContent=item.product;select.appendChild(opt);}
  if([...select.options].some(o=>o.value===selected))select.value=selected;
  select.disabled=!select.options.length;
  $('submit').disabled=!select.options.length;
  $('status').textContent='ログイン済み。現在の所持金と在庫を読み取りました。';
 }catch(e){state=null;$('submit').disabled=true;$('status').textContent='資産を取得できませんでした。';setError(e.message);}
 finally{$('refresh').disabled=false;}
}
async function preview(e){
 e.preventDefault();
 if(!state)return;
 $('submit').disabled=true;$('results').hidden=true;setError('');
 try{
  const feeNumber=Number($('fee').value);
  if(!Number.isFinite(feeNumber)||feeNumber<0||feeNumber>100)throw Error('参考手数料率は0～100%で指定してください。');
  const bps=Math.round(feeNumber*100);
  const payload={product:$('product').value,quantity:$('quantity').value.trim(),
       unit_price:$('unit-price').value.trim(),fee_bps:bps};
  const response=await request('/api/v2/preview',payload);
  if(response.mode!=='simulation_only'||response.transaction_saved!==false||response.order_placed!==false)
    throw Error('試算用API以外の応答を受信しました。');
  $('results').replaceChildren();
  for(const [key,label] of fields){
   const line=document.createElement('p');line.className='result';
   const header=document.createElement('strong');header.textContent=label;
   const out=document.createElement('output');out.textContent=String(response[key]??'');
   line.append(header,out);$('results').appendChild(line);
  }
  $('results').hidden=false;
 }catch(e){setError(e.message);}
 finally{$('submit').disabled=!state;}
}
$('refresh').addEventListener('click',refresh);
$('preview-form').addEventListener('submit',preview);
refresh();
