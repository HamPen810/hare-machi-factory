(()=>{
const root=document.querySelector('#teru-playtest'),sea=root.querySelector('.tp-sea'),doll=root.querySelector('.tp-doll');
root.querySelector('.factory-ledger').prepend(root.querySelector('.tp-money'));
const ledger=root.querySelector('.factory-ledger');
ledger.prepend(root.querySelector('#who'));new ResizeObserver(()=>{if(root.dataset.page==='factory')root.style.setProperty('--factory-canvas-top',(ledger.getBoundingClientRect().bottom-root.getBoundingClientRect().top+8)+'px');}).observe(ledger);
let sound=false,motion=true,audio=null,chain=0,lastTap=0,chainTimer,seenSale=null;
try{sound=localStorage.getItem('teru-sound')==='on';motion=localStorage.getItem('teru-motion')!=='off';}catch{}
const reduced=()=>!motion||matchMedia('(prefers-reduced-motion: reduce)').matches;
const counter=document.createElement('span');counter.className='tap-chain';counter.hidden=true;counter.title='連続タップの表示です。生産倍率は変わりません。';sea.append(counter);
const stage=document.createElement('div');stage.className='fx-stage';stage.setAttribute('aria-hidden','true');root.querySelector('#game').append(stage);
const timer=document.createElement('span');timer.className='helper-timer';timer.innerHTML='<i></i>';root.querySelector('.tp-helper-scene').append(timer);
const postcard=document.createElement('div');postcard.className='auth-postcard';postcard.setAttribute('aria-hidden','true');postcard.append(doll.cloneNode(true));root.querySelector('#auth header').after(postcard);
for(const [page,icon]of Object.entries({factory:'✦',market:'⚓',data:'▥',ranks:'♛'}))root.querySelector('[data-page='+page+']').dataset.icon=icon;
const controls=document.createElement('div');controls.className='experience-controls';const s=document.createElement('button'),m=document.createElement('button');controls.append(s,m);root.append(controls);
function prefs(){s.textContent='効果音 '+(sound?'ON':'OFF');s.setAttribute('aria-pressed',String(sound));m.textContent='演出 '+(motion?'ON':'控えめ');m.setAttribute('aria-pressed',String(motion));root.dataset.motion=motion?'on':'off';}prefs();
function tone(type){if(!sound)return;try{audio??=new AudioContext();audio.resume();const notes=type==='critical'?[660,880,1320]:type==='success'?[523,659,784]:[540];notes.forEach((freq,i)=>{const o=audio.createOscillator(),g=audio.createGain(),at=audio.currentTime+i*.06;o.type='sine';o.frequency.setValueAtTime(freq,at);g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(.045,at+.008);g.gain.exponentialRampToValueAtTime(.0001,at+.12);o.connect(g);g.connect(audio.destination);o.start(at);o.stop(at+.13);});}catch{}}
s.onclick=()=>{sound=!sound;try{localStorage.setItem('teru-sound',sound?'on':'off');}catch{}prefs();if(sound)tone('success');};m.onclick=()=>{motion=!motion;try{localStorage.setItem('teru-motion',motion?'on':'off');}catch{}prefs();};
function animate(el,frames,options){const a=el.animate(frames,options);a.onfinish=()=>el.remove();a.oncancel=()=>el.remove();return a;}
function cap(container){while(container.querySelectorAll('[data-fx]').length>55)container.querySelector('[data-fx]').remove();}
function bits(container,count,cx,cy){if(reduced())return;for(let i=0;i<count;i++){const b=document.createElement('i');b.dataset.fx='';b.className='fx-bit';b.style.cssText=`left:${cx}%;top:${cy}%;background:${['#ffe29c','#f5a486','#bbdfac','#fff8dc'][i%4]}`;container.append(b);const angle=i/count*Math.PI*2;animate(b,[{transform:'translate(0,0) rotate(0)',opacity:1},{transform:`translate(${Math.cos(angle)*110}px,${Math.sin(angle)*95-20}px) rotate(${i*54}deg)`,opacity:0}],{duration:650+i%4*80,easing:'ease-out'});}cap(container);}
let pressAnimation;
function press(){
 produced(1);
 if(reduced()||!doll.animate)return;
 bits(sea,3,47+Math.random()*6,45);
 pressAnimation?.cancel();
 pressAnimation=doll.animate([
  {transform:'scale(1)'},
  {transform:'translateY(7px) scale(.94,1.03)',offset:.3},
  {transform:'translateY(-8px) scale(1.04,.98)',offset:.65},
  {transform:'scale(1)'}
 ],{duration:270,easing:'ease-out'});
}
function produced(count,critical=false){
 if(!count)return;count=window.TeruNumber.big(count);
 const shown=reduced()?1:Number(count>100n?100n:count);
 for(let i=0;i<shown;i++){
  const label=document.createElement('span');label.className='unit-pop';label.textContent=count<=100&&!reduced()?'＋1':'＋'+(window.TeruNumber.fmt(count/BigInt(shown)+(BigInt(i)<count%BigInt(shown)?1n:0n)));
  label.style.left=(8+Math.random()*76)+'%';label.style.top=(22+Math.random()*30)+'%';if(critical)label.classList.add('gold');sea.append(label);
  animate(label,reduced()?[{opacity:1},{opacity:0}]:[{transform:'translateY(12px) scale(.5)',opacity:0},{transform:'translateY(-8px) scale(1.15)',opacity:1,offset:.2},{transform:'translateY(-95px) scale(.9)',opacity:0}],{duration:1400,delay:i*9,easing:'ease-out',fill:'both'});
 }
 while(sea.querySelectorAll('.unit-pop').length>250)sea.querySelector('.unit-pop').remove();
}
function automatic(count,name=''){
 const label=document.createElement('span');label.dataset.fx='';label.className='auto-pop';label.textContent=(name?name+' ':'')+'＋'+window.TeruNumber.big(count).toString();
 const bounds=doll.getBoundingClientRect(),parent=sea.getBoundingClientRect();label.style.left=(bounds.left-parent.left+bounds.width/2)+'px';label.style.top=(bounds.top-parent.top+bounds.height*.6)+'px';sea.append(label);
 animate(label,reduced()?[{opacity:1},{opacity:0}]:[{transform:'translate(-50%,10px) scale(.85)',opacity:0},{transform:'translate(-50%,-10px) scale(1)',opacity:1,offset:.16},{transform:'translate(-50%,-85px)',opacity:0}],{duration:1800,easing:'ease-out'});cap(sea);
}
function tap(text,critical=false,helper=false){
 const label=document.createElement('span');label.dataset.fx='';label.className='tp-float'+(critical?' is-critical':'');label.textContent=helper?'✦ 応援中':text;label.style.cssText=`position:absolute;left:${helper?5:35+Math.random()*12}%;top:${helper?64:38}%;font-size:${helper?14:critical?38:29}px`;sea.append(label);
 animate(label,reduced()?[{opacity:1},{opacity:0}]:[{transform:'translateY(10px) scale(.75)',opacity:0},{transform:'translateY(-9px) scale(1.12)',opacity:1,offset:.18},{transform:'translateY(-78px) scale(1)',opacity:0}],{duration:helper?800:1100,easing:'ease-out'});
 if(!helper){const now=performance.now();chain=now-lastTap<900?chain+1:1;lastTap=now;counter.hidden=chain<3;counter.textContent=chain+' TAP!';clearTimeout(chainTimer);chainTimer=setTimeout(()=>counter.hidden=true,1100);tone(critical?'critical':'tap');bits(sea,critical?18:5,50,45);if(critical)celebrate('おひさまボーナス！',true,false);}
 cap(sea);
}
function celebrate(text,critical=false,playSound=true){stage.querySelectorAll('.fx-word').forEach(el=>el.remove());const label=document.createElement('span');label.dataset.fx='';label.className='fx-word'+(critical?' critical':'');label.textContent=text;stage.append(label);animate(label,reduced()?[{opacity:1},{opacity:0}]:[{transform:'translate(-50%,-20%) scale(.7)',opacity:0},{transform:'translate(-50%,-50%) scale(1.06)',opacity:1,offset:.18},{transform:'translate(-50%,-75%) scale(1)',opacity:0}],{duration:1400,easing:'ease-out'});bits(stage,critical?24:16,50,40);if(playSound)tone('success');cap(stage);}
function success(kind){if(kind==='ship'){celebrate('港へ、いってらっしゃい！');if(!reduced()){const boat=document.createElement('span');boat.className='fx-boat';boat.dataset.fx='';boat.textContent='⛵';stage.append(boat);animate(boat,[{transform:'translateX(0) rotate(-4deg)'},{transform:'translateX(650px) rotate(4deg)'}],{duration:1800,easing:'ease-in-out'});}}else if(kind==='upgrade')celebrate('工場がパワーアップ！');else if(kind==='unlock')celebrate('新しい坊主が仲間入り！');else if(kind==='helper')celebrate('シーサー応援隊、到着！');}
function state(data,product){root.dataset.product=product;const f=data.factory;const helpers=f.helpers||[];const until=helpers.reduce((end,h)=>Math.max(end,h.until),f.helper_until);timer.firstElementChild.style.width=Math.max(0,Math.min(1,(until-data.now)/20000))*100+'%';const latest=data.own[0],key=latest?latest.product_id+':'+latest.accepted_at:null;if(seenSale!==null&&key&&key!==seenSale&&latest.sold_quantity>0)celebrate('売上 ＋'+latest.revenue.toLocaleString('ja-JP')+'円');seenSale=key||'none';}
root.querySelector('.tp-tap').addEventListener('pointerdown',e=>{if(e.currentTarget.disabled||reduced())return;doll.animate([{transform:'scale(1) rotate(0)'},{transform:'scale(.86,1.08) rotate(-7deg)',offset:.3},{transform:'scale(1.08,.93) rotate(5deg)',offset:.7},{transform:'scale(1) rotate(0)'}],{duration:280,easing:'ease-out'});});
window.TeruFX={press,tap,success,state,produced,automatic,rare:name=>celebrate('レア発見！ '+name,true)};
})();
