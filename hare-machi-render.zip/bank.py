"""Game-currency banking. Market and player changes use existing transaction locks."""
import json
import re
import secrets

BANK = '@bank'
HOUR_MS = 3600000
DEFAULT = {'enabled': False, 'demand_bps': 2500, 'lend_bps': 100, 'borrow_bps': 300,
           'limit': '10000', 'brackets': [], 'exponential': None}

SCHEMA = (
    "CREATE TABLE IF NOT EXISTS bank_settings (id integer PRIMARY KEY, config text NOT NULL)",
    """CREATE TABLE IF NOT EXISTS bank_accounts (
        player text PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
        deposit numeric NOT NULL DEFAULT 0, matures numeric NOT NULL DEFAULT 0,
        debt numeric NOT NULL DEFAULT 0, tax numeric NOT NULL DEFAULT 0,
        taxable_sales numeric NOT NULL DEFAULT 0)""",
    """CREATE TABLE IF NOT EXISTS bank_contracts (
        id text PRIMARY KEY,
        player text NOT NULL REFERENCES players(id) ON DELETE CASCADE,
        kind text NOT NULL,
        principal numeric NOT NULL,
        amount numeric NOT NULL,
        matures numeric NOT NULL DEFAULT 0,
        created_at numeric NOT NULL DEFAULT 0)""",
    "CREATE INDEX IF NOT EXISTS bank_contracts_player ON bank_contracts(player)",
    """CREATE TABLE IF NOT EXISTS bank_admin_actions (
        key text PRIMARY KEY, payload text NOT NULL, result text NOT NULL)""",
)

def initialize(db):
    for statement in SCHEMA:
        db.execute(statement)

def integer(value, low=0, high=None):
    if isinstance(value, str) and len(value) <= 10010:
        match = re.fullmatch(r'([0-9]+)(?:\.([0-9]+))?(?:[eE]([+-]?[0-9]{1,4}))?', value.strip())
        if match:
            whole, fraction, exponent = match.groups()
            fraction = fraction or ''
            digits = (whole + fraction).lstrip('0') or '0'
            shift = int(exponent or 0) - len(fraction)
            if digits == '0':
                value = 0
            elif shift >= 0 and len(digits) + shift <= 10000:
                value = int(digits + '0' * shift)
            elif shift < 0 and -shift < len(digits) and not digits[shift:].strip('0'):
                value = int(digits[:shift])
    if type(value) is not int or value < low or (high is not None and value > high):
        raise ValueError('指定した数値が範囲外です。')
    return value

def settings(db):
    row = db.execute('SELECT config FROM bank_settings WHERE id=1').fetchone()
    return json.loads(row[0]) if row else dict(DEFAULT)

def configure(data):
    if type(data.get('enabled')) is not bool:
        raise ValueError('銀行の有効・無効を指定してください。')
    result = {'enabled': data['enabled'], 'limit': str(integer(data.get('limit'), 1))}
    for name in ('demand_bps', 'lend_bps', 'borrow_bps'):
        result[name] = integer(data.get(name), 0, 10000)
    brackets = data.get('brackets')
    if not isinstance(brackets, list) or len(brackets) > 10:
        raise ValueError('税率の区分は10段階までです。')
    result['brackets'] = []
    prior_threshold, prior_rate = -1, 0
    for row in brackets:
        if not isinstance(row, list) or len(row) != 2:
            raise ValueError('各税率は売上の下限と税率を指定してください。')
        threshold, rate = integer(row[0]), integer(row[1], prior_rate, 10000)
        if threshold <= prior_threshold:
            raise ValueError('売上下限を小さい順に入力してください。')
        result['brackets'].append([str(threshold), rate])
        prior_threshold, prior_rate = threshold, rate
    exponential = data.get('exponential')
    result['exponential'] = None
    if exponential is not None:
        if not isinstance(exponential, dict):
            raise ValueError('指数課税の設定を確認してください。')
        base = integer(exponential.get('base_bps'), 1, 9999)
        result['exponential'] = {
            'threshold': str(integer(exponential.get('threshold'))),
            'step': str(integer(exponential.get('step'), 1)),
            'base_bps': base,
        }
    if result['lend_bps'] > result['borrow_bps']:
        raise ValueError('預け入れ利率は借入利率以下にしてください。')
    return result

def tax_due(revenue, brackets):
    total = 0
    for i, (threshold, rate) in enumerate(brackets):
        end = min(revenue, int(brackets[i+1][0])) if i+1 < len(brackets) else revenue
        total += max(0, end - int(threshold)) * rate
    return total // 10000

def exponential_tax_due(revenue, policy):
    """Double both band width and marginal rate, with no rate cap."""
    taxable = max(0, revenue - int(policy['threshold']))
    step = int(policy['step'])
    completed = (taxable // step + 1).bit_length() - 1
    multiplier = 1 << completed
    used = step * (multiplier - 1)
    # The fully taxed bands contribute a geometric series with ratio 4.
    weighted = step * (multiplier * multiplier - 1) // 3
    weighted += (taxable - used) * multiplier
    return weighted * policy['base_bps'] // 10000


def record_tax(db, player, revenue, config):
    exponential = config.get('exponential')
    if not config['enabled'] or not (config['brackets'] or exponential):
        return 0
    db.execute('INSERT INTO bank_accounts(player) VALUES(?) ON CONFLICT DO NOTHING', (player,))
    if exponential:
        if db.__class__.__module__ == 'sqlite3':
            before = sum(row[0] * row[1] for row in db.execute(
                'SELECT sold_quantity,unit_price FROM sales WHERE player_id=?', (player,)))
        else:
            before = db.execute(
                'SELECT COALESCE(SUM(sold_quantity*unit_price),0) FROM sales WHERE player_id=?',
                (player,)).fetchone()[0]
        tax = exponential_tax_due(before + revenue, exponential) - exponential_tax_due(before, exponential)
    else:
        before = db.execute('SELECT taxable_sales FROM bank_accounts WHERE player=?', (player,)).fetchone()[0]
        tax = tax_due(before + revenue, config['brackets']) - tax_due(before, config['brackets'])
    db.execute('UPDATE bank_accounts SET taxable_sales=badd(taxable_sales,?),tax=badd(tax,?) WHERE player=?',
               (revenue,tax,player))
    return tax


def _ensure_contracts(db):
    # PostgreSQL uses existing migrations for the original schema; create this
    # additive table lazily, without altering existing financial records.
    if db.__class__.__module__ != 'sqlite3':
        db.execute("""CREATE TABLE IF NOT EXISTS bank_contracts (
            id text PRIMARY KEY,
            player text NOT NULL REFERENCES players(id) ON DELETE CASCADE,
            kind text NOT NULL, principal numeric NOT NULL,
            amount numeric NOT NULL, matures numeric NOT NULL DEFAULT 0,
            created_at numeric NOT NULL DEFAULT 0)""")
        db.execute("CREATE INDEX IF NOT EXISTS bank_contracts_player ON bank_contracts(player)")

def _items(db, player):
    return [dict(row) for row in db.execute(
        'SELECT id,player,kind,principal,amount,matures,created_at '
        'FROM bank_contracts WHERE player=? ORDER BY created_at,id', (player,))]

def _legacy_entries(row, player):
    result = []
    if row and row['deposit']:
        result.append(dict(id='legacy-lend-'+player, player=player, kind='lend',
                           principal=row['deposit'], amount=row['deposit'],
                           matures=row['matures'], created_at=0))
    if row and row['debt']:
        result.append(dict(id='legacy-borrow-'+player, player=player, kind='borrow',
                           principal=row['debt'], amount=row['debt'],
                           matures=0, created_at=0))
    return result

def _migrate_legacy(db, player, row):
    # A player's old single-contract balances are migrated on their first
    # transaction. They are never removed or reset during migration.
    if _items(db, player):
        return
    for entry in _legacy_entries(row, player):
        db.execute(
            'INSERT INTO bank_contracts(id,player,kind,principal,amount,matures,created_at) '
            'VALUES(?,?,?,?,?,?,?) ON CONFLICT DO NOTHING',
            (entry['id'],entry['player'],entry['kind'],entry['principal'],
             entry['amount'],entry['matures'],entry['created_at']))

def _sync_totals(db, player):
    rows = _items(db, player)
    deposits = [r for r in rows if r['kind'] == 'lend']
    debts = [r for r in rows if r['kind'] == 'borrow']
    deposit = sum(r['amount'] for r in deposits)
    debt = sum(r['amount'] for r in debts)
    matures = min((r['matures'] for r in deposits), default=0)
    db.execute('UPDATE bank_accounts SET deposit=?,debt=?,matures=? WHERE player=?',
               (deposit,debt,matures,player))
    return rows

def player_state(db, player, now):
    _ensure_contracts(db)
    cfg = settings(db)
    row = db.execute('SELECT deposit,matures,debt,tax FROM bank_accounts WHERE player=?', (player,)).fetchone()
    result = dict(row) if row else dict(deposit=0,matures=0,debt=0,tax=0)
    contracts = _items(db, player)
    if not contracts:
        contracts = _legacy_entries(row, player)
    return {**result, 'contracts': contracts, 'now': now,
            **{k: cfg[k] for k in ('enabled','limit','lend_bps','borrow_bps')}}


def player_action(db, player, kind, quantity, now, closes_at):
    _ensure_contracts(db)
    cfg = settings(db)
    db.execute('INSERT INTO bank_accounts(player) VALUES(?) ON CONFLICT DO NOTHING', (player,))
    row = db.execute('SELECT * FROM bank_accounts WHERE player=?', (player,)).fetchone()
    _migrate_legacy(db, player, row)
    delta = 0
    ids = []
    if kind in ('bank_lend','bank_borrow'):
        if not cfg['enabled']:
            raise ValueError('現在は新規契約を受け付けていません。')
        amount = integer(quantity, 1, int(cfg['limit']))
        contract_id = secrets.token_hex(16)
        if kind == 'bank_lend':
            if now + HOUR_MS >= closes_at:
                raise ValueError('締切まで1時間以内のため預け入れできません。')
            payout = amount + amount * cfg['lend_bps'] // 10000
            db.execute('INSERT INTO bank_contracts VALUES(?,?,?,?,?,?,?)',
                       (contract_id,player,'lend',amount,payout,now+HOUR_MS,now))
            delta = -amount
        else:
            debt = amount + (amount * cfg['borrow_bps'] + 9999) // 10000
            db.execute('INSERT INTO bank_contracts VALUES(?,?,?,?,?,?,?)',
                       (contract_id,player,'borrow',amount,debt,0,now))
            delta = amount
        ids = [contract_id]
    elif kind in ('bank_withdraw','bank_repay'):
        target = 'lend' if kind == 'bank_withdraw' else 'borrow'
        contracts = _items(db, player)
        candidates = [r for r in contracts
                      if r['kind'] == target and
                      (target == 'borrow' or now >= r['matures'])]
        if quantity is not None:
            if not isinstance(quantity,str):
                raise ValueError('契約IDが不正です。')
            candidates = [r for r in candidates if r['id'] == quantity]
        if not candidates:
            raise ValueError('返済・受取が可能な契約はありません。')
        total = sum(r['amount'] for r in candidates)
        delta = total if target == 'lend' else -total
        ids = [r['id'] for r in candidates]
        # The action is already inside market.act's lock + transaction.
        for item in candidates:
            db.execute('DELETE FROM bank_contracts WHERE id=? AND player=?',
                       (item['id'],player))
    else:
        raise ValueError('銀行操作を確認してください。')

    if delta < 0:
        if db.execute('UPDATE factories SET cash=bsub(cash,?) WHERE player=? AND bge(cash,?)',
                      (-delta,player,-delta)).rowcount != 1:
            raise ValueError('所持金が足りません。')
    elif delta > 0:
        db.execute('UPDATE factories SET cash=badd(cash,?) WHERE player=?',(delta,player))
    _sync_totals(db, player)
    return {'cash_change':delta, 'contract_ids':ids}


def asset_exponent_multiplier(value):
    """10x additional tax for each complete 10 decimal-exponent levels.

    Example: 1e9 -> 1x, 1e10 -> 10x, 1e20 -> 100x.
    Uses integer arithmetic so very large game amounts do not go through float
    and do not hit Python's int-to-decimal-string conversion limit.
    """
    value = max(0, int(value))
    if value < 10**10:
        return 1
    # Estimate decimal digits from bit length, then correct exact boundaries.
    digits = ((value.bit_length() - 1) * 30103) // 100000 + 1
    if value < 10 ** (digits - 1):
        digits -= 1
    elif value >= 10 ** digits:
        digits += 1
    return 10 ** ((digits - 1) // 10)


def asset_tax(game, policy, *, apply):
    from market import PRODUCTS
    db = game.db
    if apply and game.accounts.postgres:
        db.execute('SELECT id FROM players ORDER BY id FOR NO KEY UPDATE').fetchall()
    assets = {row['player']: row['cash'] + row['deposit'] for row in db.execute(
        """SELECT f.player,f.cash,COALESCE(b.deposit,0) AS deposit
           FROM factories f LEFT JOIN bank_accounts b ON b.player=f.player""")}
    for row in db.execute("""SELECT player,product,quantity FROM stock
                             UNION ALL SELECT player,product,quantity FROM listings WHERE player<>?""",(BANK,)):
        if row['player'] in assets:
            assets[row['player']] += row['quantity'] * PRODUCTS[row['product']][1]
    # Both cash (including deposits) and all inventory valued at fixed product
    # list prices contribute to ONE exponent tier. Do not tax twice by asset type.
    taxes = [(player,exponential_tax_due(max(0,value),policy)
              * asset_exponent_multiplier(value)) for player,value in assets.items()]
    taxes = [(player,tax) for player,tax in taxes if tax]
    if apply:
        for player, tax in taxes:
            db.execute("""INSERT INTO bank_accounts(player,tax) VALUES(?,?)
                ON CONFLICT(player) DO UPDATE SET tax=badd(bank_accounts.tax,excluded.tax)""",(player,tax))
            db.execute('UPDATE factories SET cash=bsub(cash,?) WHERE player=?',(tax,player))
    return {'asset_tax':sum(tax for _,tax in taxes), 'players':len(taxes), 'applied':apply}

def admin_action(game, data):
    db = game.db
    key = data.get('key')
    if not isinstance(key,str) or not 1 <= len(key) <= 80:
        raise ValueError('操作IDが必要です。')
    payload = json.dumps(data,sort_keys=True)
    db.execute('BEGIN IMMEDIATE')
    try:
        if game.accounts.postgres:
            db.execute('SELECT pg_advisory_xact_lock(CAST(? AS bigint))',(1042119,))
        existing = db.execute('SELECT payload,result FROM bank_admin_actions WHERE key=?',(key,)).fetchone()
        if existing:
            if existing[0] != payload:
                raise ValueError('操作IDが重複しています。')
            db.rollback()
            return json.loads(existing[1])
        kind = data.get('kind')
        if kind == 'configure':
            cfg = configure(data)
            db.execute('INSERT INTO bank_settings VALUES(1,?) ON CONFLICT(id) DO UPDATE SET config=excluded.config',
                       (json.dumps(cfg),))
            result = cfg
        elif kind in ('asset_tax_preview','asset_tax_apply'):
            policy = settings(db).get('exponential')
            if not policy:
                raise ValueError('先に銀行設定で指数課税の条件を保存してください。')
            result = asset_tax(game, policy, apply=kind=='asset_tax_apply')
        else:
            from market import PRODUCTS
            product = data.get('product')
            if product not in PRODUCTS:
                raise ValueError('商品を選んでください。')
            if game.event()['phase'] != 'open':
                raise ValueError('買い取り・出品は開催中のみ実行できます。')
            now = game.clock()
            amount = integer(data.get('quantity'),0 if kind == 'offer' else 1)
            if kind == 'offer':
                price = integer(data.get('price'),1,99999)
                db.execute('DELETE FROM listings WHERE player=? AND product=?',(BANK,product))
                if amount:
                    db.execute('INSERT INTO listings VALUES(?,?,?,?,?,?,?)',
                               (secrets.token_hex(16),BANK,product,amount,price,now,now//60000))
                result = {'quantity':amount}
            elif kind == 'buyout':
                rows = db.execute('SELECT * FROM listings WHERE product=? AND player<>? ORDER BY price,accepted,id',
                                  (product,BANK)).fetchall()
                if sum(r['quantity'] for r in rows) < amount:
                    raise ValueError('買い取れる出品数が不足しています。')
                remaining, spent = amount, 0
                cfg = settings(db)
                for row in rows:
                    count = min(remaining,row['quantity'])
                    game._credit_sale(row, count, PRODUCTS[product][2], now, secrets.token_hex(16), cfg)
                    if count == row['quantity']:
                        db.execute('DELETE FROM listings WHERE id=?',(row['id'],))
                    else:
                        db.execute('UPDATE listings SET quantity=bsub(quantity,?) WHERE id=?',(count,row['id']))
                    remaining -= count
                    spent += count * row['price']
                    if not remaining:
                        break
                result = {'quantity':amount,'spent':spent}
            else:
                raise ValueError('銀行操作を確認してください。')
        db.execute('INSERT INTO bank_admin_actions VALUES(?,?,?)',(key,payload,json.dumps(result)))
        db.commit()
        return result
    except Exception:
        db.rollback()
        raise
