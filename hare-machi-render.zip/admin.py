"""Administrator authentication and a read-only operations dashboard."""
import hashlib
import hmac
import json
import secrets
from pathlib import Path

class Admin:
    def __init__(self,accounts,credential=None):
        self.db=accounts.db
        self.credential=credential or json.loads(Path(__file__).with_name('admin-credential.json').read_text())
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS admin_sessions(token_hash TEXT PRIMARY KEY,expires_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS admin_attempts(id INTEGER PRIMARY KEY CHECK(id=1),failures INTEGER NOT NULL,blocked_until INTEGER NOT NULL);
        INSERT OR IGNORE INTO admin_attempts VALUES(1,0,0);
        ''')

    def login(self,password,now):
        if not isinstance(password,str) or not 1<=len(password)<=128: raise ValueError('パスワードを確認してください。')
        self.db.execute('BEGIN IMMEDIATE')
        try:
            row=self.db.execute('SELECT * FROM admin_attempts WHERE id=1').fetchone()
            if row['blocked_until']>now: raise ValueError('ログインが一時制限されています。1分後に再度お試しください。')
            digest=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(self.credential['salt']),600000).hex()
            if not hmac.compare_digest(digest,self.credential['hash']):
                failures=(0 if row['blocked_until'] else row['failures'])+1
                self.db.execute('UPDATE admin_attempts SET failures=?,blocked_until=? WHERE id=1',(failures,now+60 if failures>=5 else 0))
                self.db.commit()
                raise ValueError('パスワードを確認してください。')
            token=secrets.token_urlsafe(32)
            self.db.execute('UPDATE admin_attempts SET failures=0,blocked_until=0 WHERE id=1')
            self.db.execute('DELETE FROM admin_sessions WHERE expires_at<=?',(now,))
            self.db.execute('INSERT INTO admin_sessions VALUES(?,?)',(hashlib.sha256(token.encode()).hexdigest(),now+3600))
            self.db.commit();return token
        except Exception:
            self.db.rollback();raise

    def authorized(self,token,now):
        return isinstance(token,str) and bool(self.db.execute('SELECT 1 FROM admin_sessions WHERE token_hash=? AND expires_at>?',(hashlib.sha256(token.encode()).hexdigest(),now)).fetchone())

    def logout(self,token):
        with self.db:self.db.execute('DELETE FROM admin_sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))

    def dashboard(self,game):
        game.rankings('manufactured')
        rankings={m:game.accounts.rankings(m) for m in ('manufactured','net_profit','revenue')}
        scores={m:{r['id']:r[m] for r in board['individual']} for m,board in rankings.items()}
        players=[]
        for r in self.db.execute('''SELECT p.id,p.student_id,p.display_name,p.class_number,
                COALESCE(f.cash,500) cash,COALESCE(f.tier,0) tier
                FROM players p LEFT JOIN factories f ON f.player=p.id ORDER BY p.student_id'''):
            row=dict(r)
            for m in scores:row[m]=scores[m][row['id']]
            row['stock']=[dict(s) for s in self.db.execute('SELECT product,quantity FROM stock WHERE player=?',(row['id'],))]
            players.append(row)
        pending=[dict(r) for r in self.db.execute('''SELECT o.id,p.display_name,p.student_id,o.product,o.quantity,o.price,o.round
                FROM listings o JOIN players p ON p.id=o.player ORDER BY o.accepted''')]
        return {'now':game.clock(),'event':game.event(),'players':players,'pending':pending,'rankings':rankings,
                'market':game.history(),'summary':{'players':len(players),'manufactured':sum(p['manufactured'] for p in players),
                'revenue':sum(p['revenue'] for p in players),'net_profit':sum(p['net_profit'] for p in players),
                'pending_shipments':len(pending),'settled_rounds':self.db.execute('SELECT COUNT(*) FROM rounds').fetchone()[0]}}
