"""Loopback-only development server. Not a production Internet server."""
from exact import wire
import argparse
import json
import logging
import sqlite3
import os
import threading
import time
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from accounts import Accounts
from market import Game
from event import OPEN_MS
from admin import Admin
from weather import forecast

STATIC=Path(__file__).with_name('static')
API_PATHS={'/api/login','/api/register','/api/logout','/api/action','/api/snapshot',
           '/api/factory','/api/ranks','/api/data','/api/market'}

def make_server(path,port=8766,clock=None,practice=False,public_origin=None,bind="127.0.0.1"):
    if public_origin:
        from urllib.parse import urlsplit
        u=urlsplit(public_origin)
        if u.scheme!="https" or not u.hostname or u.path or u.query or u.fragment:raise ValueError("Exact HTTPS public origin required")
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def reply(self,status,body,cookie=None,kind='application/json; charset=utf-8'):
            data=json.dumps(wire(body),ensure_ascii=False).encode() if kind.startswith('application/json') else body
            self.send_response(status)
            self.send_header('Content-Type',kind); self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' https://api.open-meteo.com; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            if cookie: self.send_header('Set-Cookie',cookie+('; Secure' if public_origin else ''))
            self.end_headers(); self.wfile.write(data)
        def process(self,write):
            origin=public_origin or f'http://127.0.0.1:{self.server.server_port}'
            if self.headers.get('Host')!=origin.split('://',1)[1]:
                return self.reply(403,{'error':'このサーバーはローカル専用です。'})
            if write and self.headers.get('Origin')!=origin:
                return self.reply(403,{'error':'別サイトからの操作を拒否しました。'})
            if public_origin and (self.path.startswith('/admin') or self.path.startswith('/api/admin')):
                return self.reply(404,{'error':'見つかりません。'})
            if not write and self.path == '/api/weather':return self.reply(200,forecast())
            if not write and self.path == '/fonts/Yomogi-Regular.ttf':
                return self.reply(200,(STATIC/'fonts'/'Yomogi-Regular.ttf').read_bytes(),kind='font/ttf')
            assets={'/assets/teramoto-bozu.png':'teramoto-bozu.png','/assets/mikka-bozu.png':'mikka-bozu.png','/assets/koyama-bozu.png':'koyama-bozu.png','/assets/yamada-bozu.png':'yamada-bozu.png','/assets/sea-yokai.png':'sea-yokai.png','/assets/shisa-doll.png':'shisa-doll.png','/assets/island-background.png':'island-background.png','/assets/teru-painted.png':'teru-painted.png','/assets/shisa-painted.png':'shisa-painted.png'}
            if not write and self.path in assets:
                return self.reply(200,(STATIC/'assets'/assets[self.path]).read_bytes(),kind='image/png')
            if not write and self.path in ('/','/weather.js','/app.js','/numbers.js','/polish.css','/island.css','/tabs.js','/polish.js','/admin','/admin/','/admin.js'):
                file={'/weather.js':'weather.js','/':'index.html','/app.js':'app.js','/numbers.js':'numbers.js','/polish.css':'polish.css','/island.css':'island.css','/tabs.js':'tabs.js','/polish.js':'polish.js','/admin':'admin.html','/admin/':'admin.html','/admin.js':'admin.js'}[self.path]
                return self.reply(200,(STATIC/file).read_bytes(),kind='text/html; charset=utf-8' if file.endswith('html') else 'text/css; charset=utf-8' if file.endswith('css') else 'text/javascript; charset=utf-8')
            a=None
            try:
                data={}
                if write:
                    size=int(self.headers.get('Content-Length','0'))
                    if not 0<size<=4096: return self.reply(413,{'error':'送信内容が大きすぎます。'})
                    data=json.loads(self.rfile.read(size))
                    if not isinstance(data,dict): raise ValueError('入力形式が不正です。')
                cookies=SimpleCookie(); cookies.load(self.headers.get('Cookie',''))
                token=cookies['session'].value if 'session' in cookies else ''
                if self.path in API_PATHS - {'/api/login','/api/register'} and not token:
                    return self.reply(401,{'error':'ログインしてください。'})
                read_only=not write and self.path in ('/api/data','/api/market','/api/ranks')
                player_only = (not write and self.path == '/api/factory') or (
                    write and self.path == '/api/action' and
                    data.get('kind') not in ('ship','edit_shipment','cancel_shipment','add_listing','set_price'))
                a=Accounts(path, auth_only=write and self.path in ('/api/login','/api/register','/api/logout'),
                           read_only=read_only or player_only)
                now=clock() if clock else int(time.time()*1000)
                if self.path.startswith('/api/admin/'):
                    admin=Admin(a)
                    admin_token=cookies['admin_session'].value if 'admin_session' in cookies else ''
                    if write and self.path=='/api/admin/login':
                        admin_token=admin.login(data.get('password'),now//1000)
                        return self.reply(200,{'ok':True},f'admin_session={admin_token}; HttpOnly; SameSite=Strict; Path=/api/admin; Max-Age=3600')
                    if not admin.authorized(admin_token,now//1000):return self.reply(401,{'error':'管理者ログインが必要です。'})
                    if write and self.path=='/api/admin/logout':
                        admin.logout(admin_token)
                        return self.reply(200,{'ok':True},'admin_session=; HttpOnly; SameSite=Strict; Path=/api/admin; Max-Age=0')
                    if not write and self.path=='/api/admin/dashboard':
                        return self.reply(200,admin.dashboard(Game(a,clock,opens_at=0 if practice else OPEN_MS)))
                    return self.reply(404,{'error':'見つかりません。'})
                if write and self.path=='/api/register':
                    a.register(data.get('name'),data.get('student_id'),data.get('password'),now//1000)
                    token=a.login(data['student_id'],data['password'],now//1000)
                    return self.reply(200,{'ok':True},f'session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400')
                if write and self.path=='/api/login':
                    token=a.login(data.get('student_id'),data.get('password'),now//1000)
                    return self.reply(200,{'ok':True},f'session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400')
                try: identity=a.identity(token,now//1000)
                except ValueError: return self.reply(401,{'error':'ログインしてください。'})
                if write and self.path=='/api/logout':
                    a.logout(token)
                    return self.reply(200,{'ok':True},'session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')
                g=Game(a,clock,opens_at=0 if practice else OPEN_MS,read_only=read_only or player_only)
                if write and self.path=='/api/action':
                    if isinstance(data.get('quantity'),str) and data['quantity'].isdigit():data['quantity']=int(data['quantity'])
                    result=g.act(token,data.get('key'),data.get('kind'),data.get('product','white'),data.get('quantity'),data.get('price'),data.get('target_id'))
                    if data.get('kind') in ('ship','edit_shipment','cancel_shipment','add_listing','set_price'):
                        product=data.get('product','white')
                        player=identity['id']
                        stock=a.db.execute('SELECT product,quantity,work FROM stock WHERE player=? AND product=?',(player,product)).fetchone()
                        listing=a.db.execute('SELECT id,product,quantity,price,round FROM listings WHERE player=? AND product=?',(player,product)).fetchone()
                        result={**result,'stock':dict(stock) if stock else None,'listing':dict(listing) if listing else None}
                    return self.reply(200,result)
                if not write and self.path=='/api/snapshot':
                    rankings=g.rankings_many(('manufactured','net_profit','revenue'))
                    return self.reply(200,{'identity':identity,'factory':g.state(token),'rankings':rankings,'market':g.history(),'timeline':g.timeline(token),'breakdown':g.breakdown(token),'own':a.own_history(token,now//1000),'now':now,'event':g.event()})
                if not write and self.path=='/api/factory':
                    if a.postgres:
                        revenue=a.db.execute('SELECT COALESCE(SUM(sold_quantity*unit_price),0) FROM sales WHERE player_id=?',(identity['id'],)).fetchone()[0]
                    else:
                        revenue=sum(row[0]*row[1] for row in a.db.execute(
                            'SELECT sold_quantity,unit_price FROM sales WHERE player_id=?',(identity['id'],)))
                    return self.reply(200,{'identity':identity,'factory':g.state(token),'revenue':revenue,
                                           'now':now,'event':g.event()})
                if not write and self.path=='/api/ranks':
                    return self.reply(200,{'rankings':a.rankings_many(('manufactured','net_profit','revenue'))})
                if not write and self.path=='/api/data':
                    return self.reply(200,{'timeline':g.timeline(token),'breakdown':g.breakdown(token)})
                if not write and self.path=='/api/market':
                    return self.reply(200,{'own':a.own_history(token,now//1000)})
                return self.reply(404,{'error':'見つかりません。'})
            except json.JSONDecodeError: self.reply(400,{'error':'送信内容の形式が不正です。'})
            except ValueError as error: self.reply(400,{'error':str(error)})
            except (TypeError,KeyError): self.reply(400,{'error':'入力または操作を確認してください。'})
            except sqlite3.IntegrityError: self.reply(409,{'error':'この精算回では出荷済みです。次の回に出荷できます。'})
            except sqlite3.OperationalError as error:
                cause=error.__cause__
                logging.warning('Database failure on %s (%s, SQLSTATE %s)',
                                self.path if self.path in API_PATHS else 'unknown route',
                                type(cause or error).__name__,getattr(cause,'sqlstate',None))
                self.reply(503,{'error':'処理が混み合っています。少し待ってお試しください。'})
            finally:
                if a: a.db.close()
        def do_GET(self): self.process(False)
        def do_POST(self): self.process(True)
    return ThreadingHTTPServer((bind,port),Handler)

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--port',type=int,default=int(os.environ.get('PORT','8766')))
    parser.add_argument('--bind',default='127.0.0.1');parser.add_argument('--public-origin',default=os.environ.get('HARE_FACTORY_PUBLIC_ORIGIN'));parser.add_argument('--db');parser.add_argument('--practice',action='store_true')
    args=parser.parse_args()
    args.db=args.db or os.environ.get('HARE_FACTORY_DATABASE_URL') or str(Path(__file__).with_name('practice-game.sqlite' if args.practice else 'local-game.sqlite'))
    if args.bind != '127.0.0.1' and (not args.public_origin or args.practice or not args.db.startswith(('postgresql://','postgres://'))):
        parser.error('Public binding requires HTTPS origin and PostgreSQL, with practice disabled.')
    server=make_server(args.db,args.port,practice=args.practice,public_origin=args.public_origin,bind=args.bind)
    stop=threading.Event()
    def timer():
        refresh_helpers_at = time.monotonic() + 600
        interval=1
        while not stop.wait(interval):
            interval=60
            a=None
            try:
                a=Accounts(args.db)
                if Game(a).settle(background=True):
                    interval=1
            except sqlite3.Error as error:
                logging.warning('Market settlement failed (%s)', type(error.__cause__ or error).__name__)
            finally:
                if a: a.db.close()
            if time.monotonic() < refresh_helpers_at:
                continue
            refresh_helpers_at = time.monotonic() + 600 + 600
            try:
                a=Accounts(args.db,read_only=True)
                try:
                    players=a.db.execute(Game.active_helpers_query).fetchall()
                finally:
                    a.db.close()
                for row in players:
                    if stop.is_set():
                        return
                    a=Accounts(args.db,read_only=True)
                    try:
                        game=Game(a,read_only=True)
                        with a.db:
                            game._helper(row['player'],game.clock())
                    finally:
                        a.db.close()
            except sqlite3.Error as error:
                logging.warning('Background production failed (%s)', type(error.__cause__ or error).__name__)
    threading.Thread(target=timer,daemon=True).start()
    print(f'Local game: http://127.0.0.1:{server.server_port}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: stop.set(); server.server_close()

if __name__=='__main__': main()
