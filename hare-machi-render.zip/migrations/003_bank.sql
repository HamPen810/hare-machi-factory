CREATE TABLE IF NOT EXISTS hare_factory.bank_settings (id integer PRIMARY KEY, config text NOT NULL);
CREATE TABLE IF NOT EXISTS hare_factory.bank_accounts (
        player text PRIMARY KEY REFERENCES hare_factory.players(id) ON DELETE CASCADE,
        deposit numeric NOT NULL DEFAULT 0, matures numeric NOT NULL DEFAULT 0,
        debt numeric NOT NULL DEFAULT 0, tax numeric NOT NULL DEFAULT 0,
        taxable_sales numeric NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS hare_factory.bank_admin_actions (
        key text PRIMARY KEY, payload text NOT NULL, result text NOT NULL);
ALTER TABLE hare_factory.bank_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE hare_factory.bank_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE hare_factory.bank_admin_actions ENABLE ROW LEVEL SECURITY;
