CREATE TABLE IF NOT EXISTS hare_factory.inventory_nodes (
    role text PRIMARY KEY CHECK (role IN ('A', 'B', 'C')),
    seen_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS inventory_legacy_tick ON hare_factory.factories(helper_tick)
    WHERE helper_product IS NOT NULL AND helper_tick + 1000 <= helper_until;
CREATE INDEX IF NOT EXISTS inventory_helper_tick ON hare_factory.helpers(tick);
CREATE INDEX IF NOT EXISTS inventory_line_tick ON hare_factory.autolines(tick);
