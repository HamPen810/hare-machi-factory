"""PostgreSQL connection for the existing game repository queries."""
from decimal import Decimal
import re
import sqlite3

from exact import ExactRow


def row_factory(cursor):
    def make_row(values):
        converted = [
            int(value) if isinstance(value, Decimal) and value == value.to_integral_value()
            else float(value) if isinstance(value, Decimal)
            else value
            for value in values
        ]
        return ExactRow(cursor, converted)
    return make_row


class Postgres:
    def __init__(self, url):
        import psycopg
        self.driver = psycopg
        self.connection = psycopg.connect(
            url, autocommit=True, row_factory=row_factory, connect_timeout=5,
            sslmode='verify-full', sslrootcert='system',
        )
        try:
            self.connection.execute('SET search_path TO hare_factory, pg_catalog')
            self.connection.execute("SET statement_timeout = '8s'")
            # Serialize game requests across processes, as the SQLite write lock did.
            self.connection.execute('SELECT pg_advisory_lock(1042119)')
        except psycopg.Error as error:
            self.connection.close()
            raise sqlite3.OperationalError('PostgreSQL initialization failed') from error

    def execute(self, query, params=()):
        sql = query.strip()
        if sql == 'BEGIN IMMEDIATE':
            return self.connection.execute('BEGIN')
        if sql.startswith('INSERT OR IGNORE INTO '):
            sql = sql.replace('INSERT OR IGNORE INTO ', 'INSERT INTO ', 1) + ' ON CONFLICT DO NOTHING'
        elif sql.startswith('INSERT OR REPLACE INTO market_history '):
            sql = sql.replace('INSERT OR REPLACE INTO ', 'INSERT INTO ', 1)
            sql += (' ON CONFLICT (round,product) DO UPDATE SET offered=excluded.offered,'
                    'sold=excluded.sold,revenue=excluded.revenue,sellers=excluded.sellers')
        sql = re.sub(r'\bbsum\(', 'SUM(', sql).replace('?', '%s')
        try:
            if sql.startswith(('INSERT ', 'UPDATE ', 'DELETE ')) and self.connection.info.transaction_status == self.driver.pq.TransactionStatus.IDLE:
                self.connection.execute('BEGIN')
            return self.connection.execute(sql, params)
        except self.driver.IntegrityError as error:
            raise sqlite3.IntegrityError('PostgreSQL constraint violation') from error
        except self.driver.Error as error:
            raise sqlite3.OperationalError('PostgreSQL query failed') from error

    def commit(self):
        self.connection.commit()

    def rollback(self):
        self.connection.rollback()

    def close(self):
        self.connection.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *_):
        if exc_type is None:
            self.commit()
        else:
            self.rollback()
