"""Shared Ishigaki forecast cache; no player data is sent upstream."""
import json
import time
import threading
from urllib.request import urlopen
from urllib.parse import urlencode
_lock=threading.Lock()
_cache=None
_retry=0
URL='https://api.open-meteo.com/v1/forecast?'+urlencode(dict(latitude=24.34,longitude=124.16,daily='weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',timezone='Asia/Tokyo',forecast_days=16))
def forecast():
    global _cache,_retry
    with _lock:
        now=time.time()
        if _cache and now-_cache['fetched_at']<1800:return dict(_cache,stale=False)
        if now<_retry:return dict(_cache,stale=True) if _cache else {'days':[],'stale':True,'fetched_at':None}
        try:
            with urlopen(URL,timeout=8) as response:data=json.load(response)
            daily=data['daily'];days=[]
            for i,date in enumerate(daily['time']):
                days.append({'date':date,'code':daily['weather_code'][i],'high':daily['temperature_2m_max'][i],'low':daily['temperature_2m_min'][i],'rain':daily['precipitation_probability_max'][i]})
            if not days:raise ValueError('Empty forecast')
            _cache={'days':days,'fetched_at':now};_retry=0
            return dict(_cache,stale=False)
        except (OSError,ValueError,KeyError,IndexError,TypeError):
            _retry=now+60
            return dict(_cache,stale=True) if _cache else {'days':[],'stale':True,'fetched_at':None}
